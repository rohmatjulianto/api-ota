
                         libkbcommon.jar
--------------------------------------------------------------------------------------------
Thank you for use 'libkbcommon.jar',This document describes all of the CM30 OS layer API 
interfaces that you can use to implement the functions of the Android system layer

Take a moment to review the information here before 
using the library any further.
--------------------------------------------------------------------------------------------
First:
	Import the 'libkbcommon.jar' to your project before using below APIs. And you can get the KbCommonManager instance by:

		private mKbCommonManager = KbCommonManager.getInstance();

	And than, you can call you can call all the interfaces, For example: 

		mKbCommonManager.reboot()


Secondly:
	All interfaces are described below:

      void reboot()                                                             --- Reboot the device       
      void enableStatusBar(boolean enable)                                      --- enable/disable the StatusBar
      boolean getStatusBarEnabled()                                             --- get state of statusBar
      void enableNavigationBar(boolean enable)                                  --- enable/disable the NavigationBar
      boolean getNavigationBarEnabled()                                         --- get state of NavigationBar  
      void enableDevelopmentMode(boolean enable)                                --- enable/disable the Development Mode
      boolean getDevelopmentModeEnabled()                                       --- get state of Development Mode
      void enableUsbAdb(boolean enable)                                         --- enable/disable ADB debuger
      boolean getUsbAdbEnabled()                                                --- get state of ADB debuger        
      void setWifiEnabled(boolean enable)                                       --- enable/disable wifi
      void setMobileNetworkEnabled(boolean enable)                              --- enable/disable the mobile network
      boolean setHomeActivity(ComponentName componentName)                      --- set your Home activity as default laucher
      boolean resetDefaultHome()                                                --- restore google's Launcher3 as default
      int installRomPackage(String romFilePath)                                 --- install OS firmware
      String getOSVersion()                                                     --- get the device's current OS firmware version
      String getDeviceId()                                                      --- get device's serial number
      void installAppSilent(String path, IInstallerListener listener)           --- Install an application   
      void uninstallAppSilent(String packageName, IInstallerListener listener)  --- Uninstall an application  
        
/*------------------------------------------------------------------------------------------*/
The white list is used to restrict the APP that can be loaded. Only applications 
in the white list can be loaded into the system to ensure the security of the system.
On the contrary the black list is used to restrict the APP that can not be loaded.
/*-------------------------------------------------------------------------------------------*/
APP White List APIs :
    boolean enableAppInstallWhiteList();                                        --- enable the function of App White list
    boolean disableAppInstallWhiteList();                                       --- disable the function of App White list
    boolean addAppToInstallWhiteList(String pkgName);                           --- add an application to white list
    boolean delAppFromInstallWhiteList(String pkgName);                         --- delete an application from white list
    List<String> getAppInstallWhiteList();                                      --- get the APP white list
    boolean enableAppUninstallBlackList();                                      --- enable the function of App black list
    boolean disableAppUninstallBlackList();                                     --- disable the function of App black list
    boolean addAppToUninstallBlackList(String pkgName);                         --- add an application to black list
    boolean delAppFromUninstallBlackList(String pkgName);                       --- delete an application from black list
    List<String> getAppUninstallBlackList();                                    --- get the APP black list
 
    
/** belowing new APIs added 2024-08-06 ***/

	boolean setUsbMode(int mode)                                                --- set USB mode, mode = 0: USB_HOST_MODE 
	                                                                                                     1: USB_DEVICE_MODE
	int getUsbMode()                                                            --- get USB mode, 0:USB_HOST_MODE / 1:USB_DEVICE_MODE
	void setDefaultDataSubId(int subId)                                         --- set the default mobile network data
	                                                                                          subId = 0:SIM1 
	                                                                                                  1:SIM2
    String getCellularIMEI(int subId)                                           --- get IMEI, subId = 0: IMEI1 
                                                                                                      1: IMEI2
    String getCellularICCID(int subId)                                          --- get ICCID, subId = 0: SIM1's ICCID 
                                                                                               subId = 1: SIM2's ICCID          
    String getWlanMacAddress()                                                  --- get wifi Mac address
    String getWlanIPAddress()                                                   --- get wifi IP address
    String getEth0MacAddress()                                                  --- get eth0 Mac address
    String getEth0IPAddress()                                                   --- get eth0 IP address
    
    boolean setEth0Configuration(int mothod, String ipAddress,String gateway,String dns1,String dns2)   --- config eth0, mothod = 0: DHCP / 1: STATIC IP
                                                                                                            example:
                                                                                                            //if DHCP
                                                                                                            mKbCommonManager.setEth0Configuration(0,null,null,null,null);
                                                                                                            //if static ip
                                                                                                            mKbCommonManager.setEth0Configuration(1,"192.168.1.133","192.168.1.1","8.8.8.8","8.8.4.4");
       
    int getEth0IPMethod()                                                       --- get eth0 IP Method, 0: DHCP / 1: STATIC IP
    boolean setAutoTimeSource(int source)                                       --- set NTP Automatic time, source = 0: off 
                                                                                                                     1: Automatic time by network
                                                                                                                     2: Automatic time by gps
    boolean enterKiosk(ComponentName componentName)                             ---enter kiosk mode
    boolean exitKiosk()                                                         --- exit kiosk mode
    
    
Thirdly:
       For details about how to invoke the APIs,Please refer to the 'CiontekOsApiDemo'
    
    
    
    
