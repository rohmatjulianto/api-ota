

├── Development specification for CM30-EN-V1.0.5.docx
├── CM30 Development SDK
│   ├── CM30-HardwareLibrary-1.0.5.aar  ---- CM30 Hardware sdk library
│   └── HardwareLibraryDemo.zip         ---- CM30 Hardware Library demo source code
├── MDB Cashless SDK
│   ├── mdbReader-1.0.1.aar       ---- MDB Cashless sdk library
│   └── mdbReaderDemo.zip         ---- MDB Cashless demo source code
└── ReadMe.txt
